<div class="slot-card">
  <header><slot name="header" /></header>
  <main><slot /></main>
  <footer><slot name="footer" /></footer>
</div>

<style>
  .slot-card { border: 2px dashed #ff3e00; padding: 1rem; margin: 1rem 0; }
  header, footer { font-weight: bold; }
</style>
