<script>
  import { fly } from 'svelte/transition';
  import { fade } from 'svelte/transition';

  let todos = [];
  let newTitle = '';
  let newDesc = '';
  let newDue = '';
  let newPriority = 'Medium';
  let filter = 'all';
  let priorityFilter = 'all';

  function addTodo() {
    if (newTitle.trim()) {
      todos = [
        ...todos,
        {
          id: Date.now(),
          title: newTitle.trim(),
          desc: newDesc.trim(),
          due: newDue || null,
          priority: newPriority,
          done: false,
          editing: false
        }
      ];
      newTitle = '';
      newDesc = '';
      newDue = '';
      newPriority = 'Medium';
    }
  }

  function remove(id) {
    todos = todos.filter(t => t.id !== id);
  }

  // Start edit: create temporary edit fields and set editing=true (array reassigned)
  function startEdit(id) {
    todos = todos.map(t =>
      t.id === id
        ? { ...t, editing: true, editTitle: t.title, editDesc: t.desc, editDue: t.due, editPriority: t.priority }
        : t
    );
  }

  // Save changes: copy edit fields into actual fields and clear editing
  function saveEdit(id) {
    todos = todos.map(t => {
      if (t.id !== id) return t;
      return {
        ...t,
        title: (t.editTitle ?? t.title),
        desc: (t.editDesc ?? t.desc),
        due: (t.editDue ?? t.due),
        priority: (t.editPriority ?? t.priority),
        editing: false,
        editTitle: undefined,
        editDesc: undefined,
        editDue: undefined,
        editPriority: undefined
      };
    });
  }

  // Cancel edit: discard edit fields
  function cancelEdit(id) {
    todos = todos.map(t => t.id === id ? { ...t, editing: false, editTitle: undefined, editDesc: undefined, editDue: undefined, editPriority: undefined } : t);
  }

  // Toggle done via array reassignment so filters update
  function toggleDone(id) {
    todos = todos.map(t => t.id === id ? { ...t, done: !t.done } : t);
  }

  $: filteredTodos = todos.filter(t => {
    let statusOk =
      filter === 'all' ? true :
      filter === 'active' ? !t.done :
      filter === 'done' ? t.done : true;

    let priorityOk = priorityFilter === 'all' ? true : t.priority === priorityFilter;

    return statusOk && priorityOk;
  });
</script>

<h2>📝 Advanced Todo List</h2>

<form class="new-task" on:submit|preventDefault={addTodo}>
  <input bind:value={newTitle} placeholder="Task title..." required />
  <input bind:value={newDesc} placeholder="Description..." />
  <input type="date" bind:value={newDue} />
  <select bind:value={newPriority}>
    <option>Low</option>
    <option>Medium</option>
    <option>High</option>
  </select>
  <button type="submit">➕ Add Task</button>
</form>

<!-- Filters -->
<div class="filters">
  <label>Status:
    <select bind:value={filter}>
      <option value="all">All</option>
      <option value="active">Active</option>
      <option value="done">Done</option>
    </select>
  </label>

  <label>Priority:
    <select bind:value={priorityFilter}>
      <option value="all">All</option>
      <option value="Low">Low</option>
      <option value="Medium">Medium</option>
      <option value="High">High</option>
    </select>
  </label>
</div>

{#if filteredTodos.length > 0}
  <ul>
    {#each filteredTodos as todo (todo.id)}
      <li in:fly={{ y: 20 }} out:fade class:done={todo.done}>
        <!-- use explicit change handler that reassigns the array -->
        <input type="checkbox" checked={todo.done} on:change={() => toggleDone(todo.id)} />

        {#if todo.editing}
          <!-- Edit Mode: bind to temporary edit fields -->
          <div class="edit-form">
            <input bind:value={todo.editTitle} />
            <input bind:value={todo.editDesc} />
            <input type="date" bind:value={todo.editDue} />
            <select bind:value={todo.editPriority}>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
            </select>
            <div class="edit-actions">
              <button on:click={() => saveEdit(todo.id)}>💾 Save</button>
              <button on:click={() => cancelEdit(todo.id)}>✖ Cancel</button>
            </div>
          </div>
        {:else}
          <!-- Display Mode -->
          <div class="task-details">
            <h3>{todo.title}</h3>
            {#if todo.desc}<p>{todo.desc}</p>{/if}
            {#if todo.due}<p>📅 Due: {todo.due}</p>{/if}
            <p>🔥 Priority: {todo.priority}</p>
          </div>

          <div class="task-actions">
            <button on:click={() => startEdit(todo.id)}>✏️ Edit</button>
            <button on:click={() => remove(todo.id)}>❌ Delete</button>
          </div>
        {/if}
      </li>
    {/each}
  </ul>
{:else}
  <p>No tasks available ✅</p>
{/if}

<style>
  h2 { margin-bottom: 1rem; color: #ff3e00; }
  form.new-task { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem; }
  form.new-task input, form.new-task select { flex: 1; padding: 0.4rem; }
  form.new-task button { padding: 0.5rem 1rem; background: #ff3e00; color: white; border: none; border-radius: 6px; cursor: pointer; }
  .filters { display: flex; gap: 1rem; margin-bottom: 1rem; }
  ul { list-style: none; padding: 0; }
  li { display: flex; gap: 0.8rem; align-items: flex-start; padding: 0.8rem; margin-bottom: 0.6rem; border: 1px solid #ddd; border-radius: 8px; background: #fff; }
  .done .task-details { opacity: 0.6; text-decoration: line-through; }
  .task-details { flex: 1; }
  .task-details h3 { margin: 0; }
  .task-actions { display: flex; flex-direction: column; gap: 0.3rem; }
  .edit-form { display: flex; flex-wrap: wrap; gap: 0.5rem; flex: 1; align-items: center; }
  .edit-form input, .edit-form select { flex: 1; padding: 0.3rem; }
  .edit-actions { display: flex; gap: 0.4rem; }
</style>
