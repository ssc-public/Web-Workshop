<script>
  export let name;
  export let age = 0;
</script>

<div class="card">
  <h3>{name}</h3>
  <p>Age: {age}</p>
</div>

<style>
  .card { border: 1px solid #ccc; padding: 1rem; margin: 0.5rem; }
</style>
