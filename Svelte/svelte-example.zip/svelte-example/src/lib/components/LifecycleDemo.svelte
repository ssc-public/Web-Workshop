<script>
  import { onMount, beforeUpdate, afterUpdate, onDestroy } from 'svelte';

  let count = 0;

  onMount(() => {
    console.log("Component mounted");
  });

  beforeUpdate(() => {
    console.log("Before update, count =", count);
  });

  afterUpdate(() => {
    console.log("After update, count =", count);
  });

  onDestroy(() => {
    console.log("Component destroyed");
  });

  function inc() {
    count++;
  }
</script>

<h2>Lifecycle Demo</h2>
<p>Count: {count}</p>
<button on:click={inc}>Increment</button>
