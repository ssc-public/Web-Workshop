<script>
  import { count } from '../store.js';
  import { fade } from 'svelte/transition';

  // Derived reactive value
  $: doubled = $count * 2;
</script>

<h2>Counter Example</h2>
<p in:fade>Current count: {$count} (doubled: {doubled})</p>

<button on:click={count.increment}>+</button>
<button on:click={count.decrement}>-</button>
<button on:click={count.reset}>Reset</button>
