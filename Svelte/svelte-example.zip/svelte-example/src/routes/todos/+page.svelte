<script>
  import Todo from '$lib/components/Todo.svelte';
</script>

<h1>Todos — Advanced Task Manager</h1>
<Todo />
