export async function GET() {
  return new Response(JSON.stringify([
    { id: 1, name: 'Charlie', age: 28 },
    { id: 2, name: 'Dana', age: 35 }
  ]), { headers: { 'Content-Type': 'application/json' } });
}
