<script>
  let sections = [
    {
      title: "📖 Introduction",
      content: "In the fast-moving world of web development, choosing the right framework is crucial. Svelte has emerged as a modern and innovative approach to building efficient, reactive, and interactive user interfaces."
    },
    {
      title: "📜 History",
      content: "Svelte was created by Rich Harris in 2016 while working at The New York Times. Inspired by compilers in traditional programming languages, Harris aimed to remove runtime overhead by compiling components into highly efficient JavaScript at build time. Major milestones: v1 in 2017, v2 in 2018, v3 in 2019 (bringing the modern syntax), and SvelteKit introduced around 2021."
    },
    {
      title: "⚙️ Core Concepts",
      list: [
        "Compiler-first approach → generates optimized JS at build time.",
        "Reactivity → UI updates automatically when data changes.",
        "Component-based architecture → each `.svelte` file contains HTML, JS, and CSS.",
        "No Virtual DOM → manipulates real DOM directly for better performance."
      ]
    },
    {
      title: "✨ Unique Features & Advantages",
      list: [
        "High performance → no virtual DOM overhead.",
        "Smaller bundle sizes → ships only the code you use.",
        "Simplicity → very easy syntax and low learning curve.",
        "Built-in features → state management, animations, transitions.",
        "Scoped CSS → styles are automatically component-local."
      ]
    },
    {
      title: "⚔️ Comparison with Other Frameworks",
      content: "Svelte is often compared to React, Vue, and Angular.",
      list: [
        "React → Uses Virtual DOM and JSX, has a huge ecosystem but is slower than Svelte in many cases.",
        "Vue → Simpler than React but still runtime-based. Svelte is lighter and faster but Vue has a larger ecosystem.",
        "Angular → Full-fledged framework with lots of features. Svelte is much simpler and easier to learn."
      ]
    },
    {
      title: "🏗️ Architecture",
      list: [
        "Compilation pipeline: Parsing → Analysis → Code generation → Optimization.",
        "Reactivity system: Tracked assignments trigger updates.",
        "Lifecycle hooks: onMount, beforeUpdate, afterUpdate, onDestroy."
      ]
    },
    {
      title: "🚀 Ecosystem & SvelteKit",
      content: "SvelteKit is the official application framework for building production-ready apps with Svelte. It provides:",
      list: [
        "File-based routing",
        "Server-side rendering (SSR) & static site generation (SSG)",
        "API endpoints",
        "Hot module replacement"
      ]
    },
    {
      title: "🧪 Example Applications",
      list: [
        "Todo List → Simple reactive CRUD demo.",
        "Analytical Dashboard → Uses charts (e.g. D3.js).",
        "Progressive Web Apps (PWA) → Offline support & push notifications."
      ]
    },
    {
      title: "⚠️ Challenges & Limitations",
      list: [
        "Smaller ecosystem compared to React/Vue.",
        "Fewer learning resources.",
        "Less advanced developer tooling.",
        "Small core team → slower feature adoption.",
        "Migration from other frameworks can be tricky."
      ]
    },
    {
      title: "🔮 Future of Svelte",
      list: [
        "Svelte 5 introduces 'Runes' — a new, more powerful reactivity system.",
        "Ongoing performance improvements.",
        "Better TypeScript support.",
        "Growing ecosystem & community.",
        "Server-side enhancements (edge computing, SSR)."
      ]
    },
    {
      title: "✅ Conclusion",
      content: "Svelte has carved a special place in modern frontend development. Its compiler-based approach, simplicity, performance, and small bundle size make it an attractive choice for new projects. With SvelteKit and strong community support, the future looks very bright."
    }
  ];
</script>

<h1>About Svelte</h1>
<p>
  This page summarizes Svelte’s history, key concepts, strengths, comparisons, and future directions.
  It is based on research and official documentation.
</p>

{#each sections as section}
  <section>
    <h2>{section.title}</h2>
    {#if section.content}
      <p>{section.content}</p>
    {/if}
    {#if section.list}
      <ul>
        {#each section.list as item}
          <li>{item}</li>
        {/each}
      </ul>
    {/if}
  </section>
{/each}

<style>
  h1 {
    text-align: center;
    margin-bottom: 2rem;
    color: #ff3e00;
  }
  section {
    margin-bottom: 2rem;
    padding: 1rem;
    border-left: 4px solid #ff3e00;
    background: #fff8f5;
    border-radius: 6px;
  }
  h2 {
    margin-bottom: 0.5rem;
    color: #d83600;
  }
  p { margin-bottom: 0.5rem; }
  ul {
    padding-left: 1.2rem;
    list-style-type: "✔ ";
  }
</style>
