<script>
  import Counter from '$lib/components/Counter.svelte';
  import UserCard from '$lib/components/UserCard.svelte';
  import SlotCard from '$lib/components/SlotCard.svelte';
  import LifecycleDemo from '$lib/components/LifecycleDemo.svelte';
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { fade } from 'svelte/transition';

  // Stats for demo
  let stats = { stars: 0, downloads: 0 };
  let slotClicks = 0;

  // Users data
  let users = [];
  let loading = true;

  onMount(async () => {
    // Simulate fetching project popularity
    stats = { stars: 62000, downloads: 1_200_000 };

    // Fetch from API route
    const res = await fetch('/api/users');
    users = await res.json();
    loading = false;
  });

  // Navigation to Todos
  function openTodos() {
    goto('/todos');
  }

  // Slot demo button handler
  function handleSlotClick() {
    slotClicks += 1;
    alert(`Slot button clicked ${slotClicks} time(s).`);
  }

  // User list interactivity
  function addRandomUser() {
    const names = ["Eva", "Max", "Sophia", "Liam", "Maya", "Omar"];
    const name = names[Math.floor(Math.random() * names.length)];
    const age = Math.floor(Math.random() * 40) + 20;
    const id = Date.now() + Math.random(); // unique ID
    users = [...users, { id, name, age }];
  }

  function removeUser(id) {
    users = users.filter(u => u.id !== id);
  }
</script>

<!-- ✅ Hero Section -->
<section class="hero">
  <h1>🚀 Welcome to the Svelte Showcase</h1>
  <p>
    A demo project highlighting <strong>Svelte’s unique features</strong>:
    reactivity, stores, slots, transitions, and more.
  </p>
  <a class="cta" href="/about">Learn More →</a>
</section>

<!-- ✅ Features Grid -->
<section class="features">
  <h2>🔥 Why Svelte?</h2>
  <div class="grid">
    <div class="card">⚡ <strong>Fast</strong><br/>No Virtual DOM, compiled to native JS</div>
    <div class="card">📦 <strong>Lightweight</strong><br/>Small bundle sizes</div>
    <div class="card">🎨 <strong>Simple Syntax</strong><br/>HTML + JS + CSS in one file</div>
    <div class="card">🛠 <strong>Built-in Features</strong><br/>State, transitions, scoped CSS</div>
  </div>
</section>

<!-- ✅ Live Stats -->
<section class="stats">
  <h2>📊 Project Popularity</h2>
  <p>Svelte GitHub Stars: {stats.stars.toLocaleString()}</p>
  <p>Monthly NPM Downloads: {stats.downloads.toLocaleString()}</p>
</section>

<!-- ✅ Interactive Widgets -->
<section class="widgets">
  <h2>🧩 Interactive Examples</h2>
  <div class="widget-grid">
    <div class="widget">
      <Counter />
    </div>

    <div class="widget">
      <h3>Todo Manager (preview)</h3>
      <p>
        Advanced task manager (title, description, due date, priority, inline edit).
        Open the full manager on the <strong>Todos</strong> page.
      </p>
      <button class="open-btn" on:click={openTodos}>Open Todos</button>
    </div>

    <div class="widget">
      <LifecycleDemo />
    </div>
  </div>
</section>

<!-- ✅ Slot Demo -->
<section class="slot-demo">
  <h2>🔌 Slot Example</h2>
  <SlotCard>
    <h3 slot="header">Custom Card Header</h3>
    <p>This demonstrates how content can be injected into reusable components.</p>
    <button slot="footer" on:click={handleSlotClick}>Click Me</button>
  </SlotCard>
</section>

<!-- ✅ Users Section -->
<section class="users">
  <h2>👥 Example Users</h2>

  {#if loading}
    <p>Loading users...</p>
  {:else if users.length === 0}
    <p>No users available.</p>
  {:else}
    <div class="user-grid">
      {#each users as u (u.id)}
        <div in:fade>
          <UserCard name={u.name} age={u.age} />
          <button class="remove" on:click={() => removeUser(u.id)}>❌ Remove</button>
        </div>
      {/each}

    </div>
  {/if}

  <button class="add" on:click={addRandomUser}>➕ Add Random User</button>
</section>

<!-- ✅ Footer -->
<footer>
  <p>Made with ❤️ using Svelte. <a href="https://svelte.dev" target="_blank">Official Docs</a></p>
</footer>

<style>
  section { padding: 2rem 1rem; max-width: 900px; margin: auto; }
  h1, h2 { color: #ff3e00; margin-bottom: 1rem; }
  p { margin-bottom: 1rem; }

  /* Hero */
  .hero { text-align: center; padding: 3rem 1rem; background: #fff0eb; border-radius: 1rem; }
  .cta {
    display: inline-block;
    margin-top: 1rem;
    padding: 0.6rem 1.2rem;
    background: #ff3e00; color: white;
    border-radius: 8px;
    text-decoration: none;
  }
  .cta:hover { background: #d83600; }

  /* Features */
  .features .grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
  }
  .card {
    background: #f9f9f9;
    border: 1px solid #ddd;
    padding: 1rem;
    border-radius: 8px;
    text-align: center;
  }

  /* Stats */
  .stats { text-align: center; background: #f3f3f3; border-radius: 8px; }

  /* Widgets */
  .widget-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 1.5rem;
  }
  .widget { padding: 1rem; border: 1px solid #eee; border-radius: 8px; background: #fff; }
  .open-btn { padding: 0.5rem 1rem; background: #0b74de; color: white; border: none; border-radius: 6px; cursor: pointer; }
  .open-btn:hover { background: #075aa0; }

  /* Slot Demo */
  .slot-demo { text-align: center; }

  /* Users */
  .users { text-align: center; margin-top: 2rem; }
  .user-grid {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 1rem;
  }
  .remove {
    margin-top: 0.5rem;
    background: #ff3e00;
    color: white;
    border: none;
    padding: 0.3rem 0.6rem;
    border-radius: 4px;
    cursor: pointer;
  }
  .add {
    margin-top: 1rem;
    padding: 0.5rem 1rem;
    background: #0b74de;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
  }
  .remove:hover { background: #d83600; }
  .add:hover { background: #075aa0; }

  /* Footer */
  footer {
    margin-top: 3rem;
    text-align: center;
    padding: 1rem;
    border-top: 1px solid #eee;
    font-size: 0.9rem;
    color: #555;
  }
</style>
